import { ComparisonData } from '../types';

export const fetchComparison = async (teamA: string, teamB: string): Promise<ComparisonData | null> => {
    try {
        const response = await fetch('/api/compare', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ teamA, teamB }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Erro do servidor: ${response.statusText}`);
        }

        const data: ComparisonData = await response.json();
        return data;

    } catch (error) {
        console.error("Erro ao buscar dados da comparação:", error);
        if (error instanceof Error) {
            throw new Error(`Falha na comunicação com o servidor: ${error.message}`);
        }
        throw new Error("Ocorreu um erro desconhecido ao buscar os dados.");
    }
};
